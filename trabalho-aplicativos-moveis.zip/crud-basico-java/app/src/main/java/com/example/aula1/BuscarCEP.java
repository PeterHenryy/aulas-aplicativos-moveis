package com.example.aula1;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BuscarCEP extends AppCompatActivity {

    private EditText editCEP, rua, numero, complemento, bairro, cidade, estado;
    private Button botaoCEP, salvarEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_cep);


        editCEP = findViewById(R.id.editCEP);
        rua = findViewById(R.id.rua);
        numero = findViewById(R.id.numero);
        complemento = findViewById(R.id.complemento);
        bairro = findViewById(R.id.bairro);
        cidade = findViewById(R.id.cidade);
        estado = findViewById(R.id.estado);


        botaoCEP = findViewById(R.id.botaoCEP);
        salvarEndereco = findViewById(R.id.salvarEndereco);


        botaoCEP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cep = editCEP.getText().toString();
                if (cep.length() > 0) {
                    new BuscarEnderecoTask().execute(cep);
                } else {
                    Toast.makeText(BuscarCEP.this, "Por favor digite o CEP", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    private class BuscarEnderecoTask extends AsyncTask<String, Void, JSONObject> {

        @Override
        protected JSONObject doInBackground(String... params) {
            String cep = params[0];
            try {

                String urlString = String.format("https://viacep.com.br/ws/%s/json/", cep);
                URL url = new URL(urlString);


                HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
                conexao.setRequestMethod("GET");


                int codigoResposta = conexao.getResponseCode();
                if (codigoResposta == HttpURLConnection.HTTP_OK) {

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linha;
                    while ((linha = reader.readLine()) != null) {
                        response.append(linha);
                    }
                    reader.close();


                    JSONObject respostaJson = new JSONObject(response.toString());


                    if (respostaJson.has("erro") && respostaJson.getBoolean("erro")) {
                        return null; // CEP not found
                    }

                    return respostaJson;
                } else {

                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(JSONObject resultado) {
            if (resultado != null) {
                try {

                    rua.setText(resultado.getString("logradouro"));
                    bairro.setText(resultado.getString("bairro"));
                    cidade.setText(resultado.getString("localidade"));
                    estado.setText(resultado.getString("uf"));

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(BuscarCEP.this, "Erro ocorreu ao tentar buscar dados.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(BuscarCEP.this, "CEP nao encontrado.", Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void irParaMain(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
